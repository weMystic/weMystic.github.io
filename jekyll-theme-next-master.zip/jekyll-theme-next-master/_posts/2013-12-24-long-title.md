---
title:  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam justo turpis, tincidunt ac convallis id.
date: 2013-12-24 23:31:06
categories:
- Foo
tags:
- Foo
---

This post has a long title. Make sure the title displayed right.
